import os
import sys
import requests

import pygame
from pygame.locals import *

from calc.graphing import Graph
from widgets.slider import Slider

# Versioning
version = "alpha-0.1"
# github_url = "https://api.github.com/repos/devkapa/InsidiaDiff/releases/latest"

# Enable double buffer
flags = DOUBLEBUF

# Initialise pygame modules
pygame.font.init()
pygame.display.init()

# RGB colour constants
WHITE = (255, 255, 255)
YELLOW = (253, 248, 140)
AQUA = (0, 255, 255)
PINK = (255, 225, 225)
RED = (255, 0, 0)
GREEN = (0, 255, 0)
GRAY = (168, 168, 168)
BLACK = (0, 0, 0)
BACKGROUND_COLOUR = (14, 17, 23)
SIDEBAR_COLOUR = (38, 39, 48)
SIDEBAR_HIGHLIGHT = (58, 59, 70)

# Size constants
WIDTH, HEIGHT = 1200, 800
SIDEBAR_WIDTH, SIDEBAR_HEIGHT = 250, HEIGHT
SIDEBAR_PADDING = 10

# Create an opaque window surface with defined width and height, and set a title
WIN = pygame.display.set_mode((WIDTH, HEIGHT), flags, 8)
WIN.set_alpha(None)
pygame.display.set_caption("Insidia")

# Set the icon of the window
ICON = pygame.image.load(os.path.join('assets', 'textures', 'logo.png'))
pygame.display.set_icon(ICON)

# Frames per second constant
FPS = 120

# Fonts
TITLE, SUBHEADING, REGULAR, PRESS_START = 'Oxanium-Bold.ttf', 'Oxanium-Medium.ttf', \
    'Oxanium-Regular.ttf', 'press-start.ttf'

# Enum values for code readability
HOME, SCIENTIFIC, GRAPHING, SETTINGS = 0, 1, 2, 3
RETRACTED, EXTENDED = 0, 1
SIDEBAR_SURFACE, SIDEBAR_BUTTON, SIDEBAR_PAGES = 0, 1, 2


# Returns a surface with text in the game font
def render_text(text, px, font=REGULAR, color=WHITE, alpha=None):
    font = pygame.font.Font(os.path.join('assets', 'fonts', font), px)
    text = font.render(text, True, color)
    text.set_alpha(alpha) if alpha is not None else None
    return text


# Create a sidebar depending on whether it is extended or not
def get_sidebar(sidebar, status):
    if sidebar == EXTENDED:

        # Sidebar background
        sidebar_surface = pygame.Surface((SIDEBAR_WIDTH, SIDEBAR_HEIGHT))
        sidebar_surface.fill(SIDEBAR_COLOUR)

        # Close button
        close_button = pygame.Rect(
            SIDEBAR_WIDTH - 30 - SIDEBAR_PADDING, SIDEBAR_PADDING, 30, 30)
        close_text = render_text("X", 35 if close_button.collidepoint(
            pygame.mouse.get_pos()) else 30, font=TITLE)
        sidebar_surface.blit(close_text, (SIDEBAR_WIDTH -
                             close_text.get_width() - SIDEBAR_PADDING, SIDEBAR_PADDING))

        # Pages
        pages = ["Home", "Scientific Calculator",
                 "Graphing Calculator", "Settings"]
        pygame.display.set_caption(f"{pages[status]} • Insidia")
        for index, page in enumerate(pages):
            page_button = pygame.Surface(
                (SIDEBAR_WIDTH - (SIDEBAR_PADDING*2), 30))
            page_rect = pygame.Rect(
                (SIDEBAR_PADDING, 100+(index*40)), (SIDEBAR_WIDTH - (SIDEBAR_PADDING*2), 30))
            page_button.fill(SIDEBAR_HIGHLIGHT if status == index or page_rect.collidepoint(
                pygame.mouse.get_pos()) else SIDEBAR_COLOUR)
            page_text = render_text(page, 20)
            page_button.blit(page_text, (SIDEBAR_PADDING, 5))
            sidebar_surface.blit(
                page_button, (SIDEBAR_PADDING, 100+(index*40)))
            pages[index] = page_rect

        # Page specific controls

        return sidebar_surface, close_button, pages

    if sidebar == RETRACTED:
        open_button = pygame.Rect(SIDEBAR_PADDING, SIDEBAR_PADDING, 30, 30)
        open_text = render_text("»", 35 if open_button.collidepoint(
            pygame.mouse.get_pos()) else 30, font=TITLE)
        return open_text, open_button


def draw_home(sidebar_offset, graph, sliders):
    WIN.fill(BACKGROUND_COLOUR)
    title = render_text("Insidia: Your partner in math", 40, font=TITLE)
    WIN.blit(title, (sidebar_offset + 80, 80))
    WIN.blit(graph.create((-10, 10), (-5, 5), scale_x=sliders[0].value(), scale_y=sliders[1].value()),
             (sidebar_offset + 80, 190))
    graph.set_pos((sidebar_offset + 80, 190))
    accumulated = 0
    for slider in sliders:
        surface = slider.create()
        WIN.blit(surface, (sidebar_offset + 700, 190 + (accumulated)))
        slider.set_pos((sidebar_offset + 700, 190 + (accumulated)))
        accumulated += surface.get_height() + 20


def draw_scientific():
    WIN.fill(BACKGROUND_COLOUR)


def draw_graphing():
    WIN.fill(BACKGROUND_COLOUR)


def draw_settings():
    WIN.fill(BACKGROUND_COLOUR)


def main():
    # Initialise pygame's clock and start the game loop
    clock = pygame.time.Clock()
    running = True

    # Set the initial state to the title screen
    current_state = HOME
    # update_message = ""

    # Set the sidebar to default open
    sidebar_state = EXTENDED
    sidebar_anim_frames = 0

    # Check for updates from GitHub - if this version doesn't match the latest version
    # If there is no internet, print error but run program
    # try:
    #    response = requests.get(github_url, timeout=3)
    #    if response.json()["tag_name"] != version:
    #        update_message = "There is a new version available! Click here to download."
    # except requests.ConnectionError:
    #    update_message = "Cannot check for updates."
    # except requests.Timeout:
    #    update_message = "Cannot check for updates."

    clicked = None

    graph = Graph("", (600, 300))
    scale_x_slider = Slider(25, 100, 200, 10, 10)
    scale_y_slider = Slider(25, 100, 200, 10, 10)
    sliders = [scale_x_slider, scale_y_slider]

    while running:

        # Limit the loop to run only 60 times per second
        clock.tick(FPS)

        # Get sidebar surface and button rects
        sidebar = get_sidebar(sidebar_state, current_state)

        # Iterate through pygame events
        for event in pygame.event.get():

            # Exit the program if the user quit
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            # Check if the user clicked the mouse
            if event.type == pygame.MOUSEBUTTONDOWN:

                # Change sidebar state if button is pressed
                if sidebar[SIDEBAR_BUTTON].collidepoint(event.pos):
                    if sidebar_state == EXTENDED:
                        sidebar_state = RETRACTED
                    else:
                        sidebar_state = EXTENDED
                        sidebar_anim_frames = SIDEBAR_WIDTH

                # Reload sidebar after state change
                sidebar = get_sidebar(sidebar_state, current_state)

                # Change program state if sidebar page button is pressed
                if len(sidebar) > SIDEBAR_PAGES:
                    for state in [HOME, SCIENTIFIC, GRAPHING, SETTINGS]:
                        if sidebar[SIDEBAR_PAGES][state].collidepoint(event.pos):
                            current_state = state

        if current_state == HOME:
            draw_home(230 if sidebar_state == EXTENDED else 0,
                      graph, [scale_x_slider, scale_y_slider])

            buttons_pressed = pygame.mouse.get_pressed(num_buttons=3)

            if clicked == None:
                hovered = False
                if graph.viewing_surface.get_rect(topleft=graph.get_pos()).collidepoint(pygame.mouse.get_pos()):
                    pygame.mouse.set_cursor(pygame.SYSTEM_CURSOR_SIZEALL)
                    hovered = True
                for slider in sliders:
                    if slider.current_surface.get_rect(topleft=slider.get_pos()).collidepoint(pygame.mouse.get_pos()):
                        pygame.mouse.set_cursor(pygame.SYSTEM_CURSOR_SIZEWE)
                        hovered = True

            pygame.mouse.set_cursor(
                pygame.SYSTEM_CURSOR_ARROW) if not hovered else None

            if graph.get_clicked():
                pygame.mouse.set_visible(False)
                last_pos = graph.get_mouse_pos()
                graph.shift_x(pygame.mouse.get_pos()[0] - last_pos[0])
                graph.shift_y(pygame.mouse.get_pos()[1] - last_pos[1])
                graph.set_clicked(True, pygame.mouse.get_pos())

            if buttons_pressed[0]:
                for slider in sliders:
                    if slider == clicked or clicked == None:
                        if slider.current_surface.get_rect(topleft=slider.get_pos()).collidepoint(pygame.mouse.get_pos()):
                            slider.set_clicked(True)
                            clicked = slider
                if graph == clicked or clicked == None:
                    if graph.viewing_surface.get_rect(topleft=graph.get_pos()).collidepoint(pygame.mouse.get_pos()):
                        graph.set_clicked(True, pygame.mouse.get_pos())
                        clicked = graph
            else:
                pygame.mouse.set_visible(True)
                clicked = None
                if graph.get_clicked():
                    graph.set_clicked(False)
                for slider in sliders:
                    if slider.get_clicked():
                        slider.set_clicked(False)

            for slider in sliders:
                if slider.get_clicked():
                    pygame.mouse.set_cursor(pygame.SYSTEM_CURSOR_SIZEWE)
                    if pygame.mouse.get_pos()[0] <= slider.get_pos()[0] + slider.radius:
                        slider.current_x = slider.radius
                        continue
                    if pygame.mouse.get_pos()[0] >= slider.get_pos()[0] + slider.size_x + slider.radius:
                        slider.current_x = slider.size_x + slider.radius
                        continue
                    slider.current_x = pygame.mouse.get_pos()[
                        0] - slider.get_pos()[0]

        if current_state == SCIENTIFIC:
            draw_scientific()

        if current_state == GRAPHING:
            draw_graphing()

        if current_state == SETTINGS:
            draw_settings()

        # Draw the sidebar onto the screen
        if sidebar_state == EXTENDED:
            WIN.blit(sidebar[SIDEBAR_SURFACE], (0 - sidebar_anim_frames, 0))
            sidebar_anim_frames -= 25 if 0 < sidebar_anim_frames else 0
        else:
            WIN.blit(sidebar[SIDEBAR_SURFACE], (10, 10))

        pygame.display.update()


if __name__ == '__main__':
    main()
